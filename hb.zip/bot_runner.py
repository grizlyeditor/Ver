import asyncio
import sys
import json
import logging
import signal
import argparse
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BotRunner:
    def __init__(self, bot_id: str, config: dict):
        self.bot_id = bot_id
        self.config = config
        self.running = False
        
    async def start(self):
        logger.info(f"Starting bot {self.bot_id}")
        self.running = True
        
        # Send initial status
        await self._send_status({
            "status": "starting",
            "current_target": self.config.get("target_player"),
            "current_mode": self.config.get("game_mode", "lone-wolf")
        })
        
        # Simulate bot running
        counter = 0
        while self.running and counter < 5:  # Run 5 games for demo
            await self._send_status({
                "status": "running",
                "games_played": counter
            })
            
            await self._send_log(f"Playing game {counter + 1}")
            
            # Simulate game play
            await asyncio.sleep(10)
            
            counter += 1
            
            await self._send_status({
                "status": "running",
                "games_played": counter
            })
            
        await self._send_status({"status": "stopped"})
        
    async def stop(self):
        logger.info(f"Stopping bot {self.bot_id}")
        self.running = False
        
    async def handle_command(self, command: dict):
        cmd = command.get("command")
        
        if cmd == "stop":
            await self.stop()
        elif cmd == "status":
            await self._send_status({"status": "running" if self.running else "stopped"})
            
    async def _send_status(self, data: dict):
        message = {"type": "status", "bot_id": self.bot_id, "data": data}
        print(json.dumps(message))
        sys.stdout.flush()
        
    async def _send_log(self, message: str):
        log_msg = {"type": "log", "bot_id": self.bot_id, "message": message, "level": "info"}
        print(json.dumps(log_msg))
        sys.stdout.flush()

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bot-id", required=True)
    parser.add_argument("--uid", required=True)
    parser.add_argument("--password", required=True)
    parser.add_argument("--target")
    parser.add_argument("--mode", default="lone-wolf")
    parser.add_argument("--region", default="global")
    
    args = parser.parse_args()
    
    config = {
        "uid": args.uid,
        "password": args.password,
        "target_player": args.target,
        "game_mode": args.mode,
        "region": args.region
    }
    
    runner = BotRunner(args.bot_id, config)
    
    # Handle signals
    loop = asyncio.get_event_loop()
    
    def signal_handler():
        asyncio.create_task(runner.stop())
        
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, signal_handler)
        
    try:
        # Start runner
        bot_task = asyncio.create_task(runner.start())
        
        # Handle commands from stdin
        while runner.running:
            try:
                line = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)
                if line:
                    command = json.loads(line.strip())
                    await runner.handle_command(command)
            except json.JSONDecodeError:
                continue
            except Exception as e:
                logger.error(f"Error: {str(e)}")
                await asyncio.sleep(1)
                
        await bot_task
        
    except KeyboardInterrupt:
        await runner.stop()

if __name__ == "__main__":
    asyncio.run(main())