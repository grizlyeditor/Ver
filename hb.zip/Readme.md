# Free Fire Bot Web Control System

A web-based control panel for managing Free Fire automation bots.

## Features

- Web-based dashboard for bot control
- Real-time status monitoring
- Multiple bot instance management
- Game statistics tracking
- Responsive design
- Secure API with token authentication

## Quick Start

### Prerequisites
- Python 3.8+
- pip package manager
- Free Fire account credentials

### Installation

1. **Clone or extract the project:**
```bash
git clone <repository-url>
cd ff-bot-web-system