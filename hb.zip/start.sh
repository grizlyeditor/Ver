

echo "Starting Free Fire Bot Web System..."

# Check Python version
python --version || echo "Python not found!"

# Create virtual environment if not exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install backend dependencies
echo "Installing backend dependencies..."
cd backend
pip install -r requirements.txt

# Install bot dependencies
echo "Installing bot dependencies..."
cd ../bot
pip install -r requirements.txt
cd ..

# Start backend server
echo "Starting backend server..."
cd backend
python run.py &
BACKEND_PID=$!

# Wait for backend to start
sleep 3

# Start frontend server
echo "Starting frontend server..."
cd ../frontend
python -m http.server 3000 &
FRONTEND_PID=$!

echo "========================================="
echo "System started successfully!"
echo "Frontend: http://localhost:3000"
echo "Backend API: http://localhost:8000"
echo "Login: admin / admin123"
echo "========================================="
echo "Press Ctrl+C to stop all servers"

# Wait for interrupt
trap "kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait