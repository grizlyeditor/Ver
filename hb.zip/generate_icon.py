# generate_icons.py
from PIL import Image, ImageDraw
import os

# Create assets directory if not exists
os.makedirs('frontend/assets', exist_ok=True)

# Define sizes
sizes = [72, 96, 128, 144, 152, 192, 384, 512]

for size in sizes:
    # Create a simple icon with robot
    img = Image.new('RGBA', (size, size), (67, 97, 238, 255))
    draw = ImageDraw.Draw(img)
    
    # Draw a simple robot icon
    margin = size // 4
    draw.rectangle([margin, margin, size-margin, size-margin], 
                   fill=(255, 255, 255, 255))
    
    # Save
    img.save(f'frontend/assets/icon-{size}.png')
    print(f'Created icon-{size}.png')