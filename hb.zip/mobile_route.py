from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer
from typing import Dict, List
import json

from app.models import BotConfig, BotStatus
from app.bot_manager import bot_manager

router = APIRouter(prefix="/mobile", tags=["mobile"])
security = HTTPBearer()

def verify_mobile_token(token: str = Depends(security)):
    # Simple token verification for mobile
    if token.credentials != "mobile-secret-token":
        raise HTTPException(status_code=401, detail="Invalid mobile token")
    return True

@router.post("/start")
async def mobile_start_bot(
    config: Dict,
    auth: bool = Depends(verify_mobile_token)
):
    """Mobile-friendly bot start endpoint"""
    try:
        # Convert mobile config to BotConfig
        bot_config = BotConfig(
            uid=config.get("uid"),
            password=config.get("password"),
            target_player=config.get("target_player"),
            game_mode=config.get("game_mode", "lone-wolf"),
            max_games=config.get("max_games", 10),
            auto_restart=config.get("auto_restart", True)
        )
        
        # Generate simple bot ID
        import uuid
        bot_id = str(uuid.uuid4())[:8]
        
        # Start bot
        success = await bot_manager.start_bot(bot_id, bot_config)
        
        if success:
            return {
                "success": True,
                "bot_id": bot_id,
                "message": "Bot started successfully"
            }
        else:
            return {
                "success": False,
                "message": "Failed to start bot"
            }
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/status/{bot_id}")
async def mobile_bot_status(
    bot_id: str,
    auth: bool = Depends(verify_mobile_token)
):
    """Get simplified bot status for mobile"""
    if bot_id not in bot_manager.active_bots:
        raise HTTPException(status_code=404, detail="Bot not found")
    
    bot_data = bot_manager.active_bots[bot_id]
    
    # Calculate uptime in minutes
    uptime_minutes = 0
    if bot_data["status"].status == "running":
        from datetime import datetime
        uptime_seconds = (datetime.now() - bot_data["started_at"]).total_seconds()
        uptime_minutes = int(uptime_seconds / 60)
    
    return {
        "status": bot_data["status"].status,
        "games_played": bot_data["status"].games_played,
        "success_rate": bot_data["status"].success_rate,
        "uptime_minutes": uptime_minutes,
        "current_target": bot_data["status"].current_target,
        "current_mode": bot_data["status"].current_mode.value,
        "connection": bot_data["status"].connection_status
    }

@router.post("/stop/{bot_id}")
async def mobile_stop_bot(
    bot_id: str,
    auth: bool = Depends(verify_mobile_token)
):
    """Stop bot from mobile"""
    success = await bot_manager.stop_bot(bot_id)
    
    if success:
        return {"success": True, "message": "Bot stopped"}
    else:
        return {"success": False, "message": "Bot not found"}

@router.get("/quick_stats")
async def mobile_quick_stats(auth: bool = Depends(verify_mobile_token)):
    """Get quick stats for mobile dashboard"""
    total_bots = len(bot_manager.active_bots)
    running_bots = sum(1 for b in bot_manager.active_bots.values() 
                      if b["status"].status == "running")
    total_games = sum(b["status"].games_played for b in bot_manager.active_bots.values())
    
    return {
        "total_bots": total_bots,
        "running_bots": running_bots,
        "total_games": total_games,
        "active_since": min([b["started_at"] for b in bot_manager.active_bots.values()], 
                           default=None)
    }

@router.post("/command")
async def mobile_send_command(
    command: Dict,
    auth: bool = Depends(verify_mobile_token)
):
    """Send command to bot from mobile"""
    bot_id = command.get("bot_id")
    cmd = command.get("command")
    
    if not bot_id or not cmd:
        raise HTTPException(status_code=400, detail="Missing bot_id or command")
    
    if bot_id not in bot_manager.active_bots:
        raise HTTPException(status_code=404, detail="Bot not found")
    
    # Send command to bot
    success = await bot_manager.send_to_bot(bot_id, command)
    
    return {"success": success, "message": "Command sent"}