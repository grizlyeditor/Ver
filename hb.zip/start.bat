@echo off
echo Starting Free Fire Bot Web System...

REM Check Python
python --version
if errorlevel 1 (
    echo Python not found!
    pause
    exit /b 1
)

REM Create virtual environment
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)

REM Activate virtual environment
call venv\Scripts\activate.bat

REM Install backend dependencies
echo Installing backend dependencies...
cd backend
pip install -r requirements.txt

REM Install bot dependencies
echo Installing bot dependencies...
cd ..\bot
pip install -r requirements.txt
cd ..

REM Start backend server
echo Starting backend server...
start /B python backend/run.py

REM Wait for backend
timeout /t 5 /nobreak >nul

REM Start frontend server
echo Starting frontend server...
cd frontend
start /B python -m http.server 3000
cd ..

echo =========================================
echo System started successfully!
echo Frontend: http://localhost:3000
echo Backend API: http://localhost:8000
echo Login: admin / admin123
echo =========================================
echo Press any key to stop servers...
pause >nul

REM Kill processes (simplified)
taskkill /F /IM python.exe >nul 2>&1