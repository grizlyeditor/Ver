from pydantic_settings import BaseSettings
from typing import List, Optional

class Settings(BaseSettings):
    # API Settings
    APP_NAME: str = "Free Fire Bot Control"
    VERSION: str = "1.0.0"
    DEBUG: bool = True
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Security
    API_TOKEN: str = "ff-bot-secret-token-2024"
    SECRET_KEY: str = "your-secret-key-here-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    
    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8080",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8080",
    ]
    
    # Admin credentials
    ADMIN_USER: str = "admin"
    ADMIN_PASS: str = "admin123"
    
    # Bot Settings
    MAX_BOTS_PER_USER: int = 5
    BOT_TIMEOUT_SECONDS: int = 300
    LOG_RETENTION_DAYS: int = 7
    
    # Paths
    BOT_CODE_PATH: str = "../bot"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()