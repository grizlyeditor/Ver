from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from contextlib import asynccontextmanager
import asyncio
import json
import logging
from typing import Dict, List
import uuid
from datetime import datetime
import os

from app.models import BotConfig, BotStatus, Command, LoginRequest
from app.websocket_manager import ConnectionManager
from app.bot_manager import BotManager
from app.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

security = HTTPBearer()

bot_manager = BotManager()
connection_manager = ConnectionManager()

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Free Fire Bot Server...")
    yield
    logger.info("Shutting down...")
    await bot_manager.stop_all_bots()

app = FastAPI(
    title="Free Fire Bot Control",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Simple token verification
def verify_token(token: str = Depends(security)):
    if token.credentials != settings.API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid token")
    return True

@app.get("/")
async def root():
    """Serve frontend"""
    try:
        with open("../frontend/index.html", "r") as f:
            return HTMLResponse(content=f.read())
    except:
        return {"message": "Free Fire Bot Control API"}

@app.get("/api/health")
async def health():
    return {"status": "ok", "timestamp": datetime.now().isoformat()}

@app.post("/api/auth/login")
async def login(request: LoginRequest):
    if request.username == settings.ADMIN_USER and request.password == settings.ADMIN_PASS:
        return {
            "access_token": settings.API_TOKEN,
            "token_type": "bearer",
            "user": {"username": request.username, "role": "admin"}
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.post("/api/bot/start")
async def start_bot(config: BotConfig, auth: bool = Depends(verify_token)):
    bot_id = str(uuid.uuid4())[:8]
    
    success = await bot_manager.start_bot(bot_id, config)
    
    if not success:
        raise HTTPException(status_code=500, detail="Failed to start bot")
    
    await connection_manager.broadcast({
        "type": "bot_status",
        "bot_id": bot_id,
        "status": "starting"
    })
    
    return {"bot_id": bot_id, "status": "starting"}

@app.post("/api/bot/{bot_id}/stop")
async def stop_bot(bot_id: str, auth: bool = Depends(verify_token)):
    success = await bot_manager.stop_bot(bot_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="Bot not found")
    
    await connection_manager.broadcast({
        "type": "bot_status",
        "bot_id": bot_id,
        "status": "stopped"
    })
    
    return {"bot_id": bot_id, "status": "stopped"}

@app.get("/api/bots")
async def list_bots(auth: bool = Depends(verify_token)):
    bots = []
    for bot_id, bot_data in bot_manager.active_bots.items():
        bots.append({
            "bot_id": bot_id,
            "status": bot_data["status"].dict(),
            "config": bot_data["config"].dict(),
            "started_at": bot_data["started_at"].isoformat()
        })
    
    return {"bots": bots}

@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await connection_manager.connect(client_id, websocket)
    
    try:
        # Send initial state
        await websocket.send_json({
            "type": "connected",
            "client_id": client_id,
            "bots": [
                {
                    "bot_id": bot_id,
                    "status": bot_data["status"].dict()
                }
                for bot_id, bot_data in bot_manager.active_bots.items()
            ]
        })
        
        while True:
            data = await websocket.receive_json()
            
            if data.get("type") == "command":
                bot_id = data.get("bot_id")
                if bot_id:
                    await bot_manager.send_to_bot(bot_id, data)
                    
    except WebSocketDisconnect:
        connection_manager.disconnect(client_id)
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")

# Serve static files
app.mount("/static", StaticFiles(directory="../frontend/static"), name="static")
app.mount("/assets", StaticFiles(directory="../frontend/assets"), name="assets")
app.mount("/css", StaticFiles(directory="../frontend"), name="css")
app.mount("/js", StaticFiles(directory="../frontend"), name="js")