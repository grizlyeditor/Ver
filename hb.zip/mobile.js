// Global variables
let currentAction = null;
let pullStartY = null;
let isRefreshing = false;
let deviceType = 'mobile';

// Detect device type
function detectDevice() {
    const userAgent = navigator.userAgent.toLowerCase();
    const isMobile = /iphone|ipad|ipod|android|webos|blackberry|windows phone/.test(userAgent);
    const isTablet = /(ipad|tablet|playbook|silk)|(android(?!.*mobile))/i.test(userAgent);
    
    if (isMobile) {
        deviceType = 'mobile';
        document.body.classList.add('mobile-device');
    } else if (isTablet) {
        deviceType = 'tablet';
        document.body.classList.add('tablet-device');
    } else {
        deviceType = 'desktop';
        document.body.classList.add('desktop-device');
    }
    
    // Add touch class for touch devices
    if ('ontouchstart' in window || navigator.maxTouchPoints) {
        document.body.classList.add('touch-device');
    }
}

// Toggle sidebar on mobile
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
    
    // Prevent body scrolling when sidebar is open
    if (sidebar.classList.contains('active')) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = '';
    }
}

// Mobile-specific bot control functions
function startBotFromMobile() {
    const uid = document.getElementById('mobile-uid').value.trim();
    const password = document.getElementById('mobile-password').value.trim();
    const target = document.getElementById('mobile-target-input').value.trim();
    const mode = document.querySelector('.mode-btn.active').dataset.mode;
    
    if (!uid || !password) {
        showMobileToast('Please enter UID and password', 'error');
        return;
    }
    
    showLoading(true);
    
    // Store credentials for future use
    localStorage.setItem('ff_bot_uid', uid);
    localStorage.setItem('ff_bot_password', password);
    if (target) {
        localStorage.setItem('ff_bot_target', target);
    }
    
    const config = {
        uid: uid,
        password: password,
        target_player: target || undefined,
        game_mode: mode,
        auto_restart: document.getElementById('auto-restart').checked,
        max_games: parseInt(document.getElementById('max-games').value) || 10
    };
    
    // Call the backend API
    fetch('/api/bot/start', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify(config)
    })
    .then(response => response.json())
    .then(data => {
        showLoading(false);
        if (data.bot_id) {
            showMobileToast('Bot started successfully', 'success');
            updateMobileStatus('starting');
        } else {
            showMobileToast('Failed to start bot', 'error');
        }
    })
    .catch(error => {
        showLoading(false);
        showMobileToast('Connection error', 'error');
        console.error('Error:', error);
    });
}

function setMobileTarget() {
    const targetInput = document.getElementById('mobile-target-input');
    const target = targetInput.value.trim();
    
    if (target && /^\d+$/.test(target)) {
        localStorage.setItem('ff_bot_target', target);
        document.getElementById('mobile-target').textContent = target;
        showMobileToast(`Target set to: ${target}`, 'success');
    } else {
        showMobileToast('Please enter a valid player ID', 'error');
    }
}

function selectMobileMode(mode) {
    const buttons = document.querySelectorAll('.mode-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.mode === mode) {
            btn.classList.add('active');
        }
    });
    
    document.getElementById('mobile-mode').textContent = 
        mode === 'lone-wolf' ? 'Lone Wolf' :
        mode === 'squad' ? 'Squad' : 'Duo';
        
    localStorage.setItem('ff_bot_mode', mode);
}

// Update mobile status display
function updateMobileStatus(status) {
    const statusElement = document.getElementById('mobile-bot-status');
    const statusDot = document.getElementById('mobile-status-dot');
    const startBtn = document.getElementById('mobile-start-btn');
    const stopBtn = document.getElementById('mobile-stop-btn');
    
    statusElement.textContent = status.toUpperCase();
    statusElement.className = 'status-badge ' + status;
    statusDot.className = 'status-dot ' + status;
    
    if (status === 'running' || status === 'starting') {
        startBtn.disabled = true;
        stopBtn.disabled = false;
        startBtn.style.opacity = '0.5';
        stopBtn.style.opacity = '1';
    } else {
        startBtn.disabled = false;
        stopBtn.disabled = true;
        startBtn.style.opacity = '1';
        stopBtn.style.opacity = '0.5';
    }
}

// Mobile toast notifications
function showMobileToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    
    const toast = document.createElement('div');
    toast.className = `toast-mobile ${type}`;
    toast.innerHTML = `
        <i class="fas ${getMobileToastIcon(type)}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'toastSlideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function getMobileToastIcon(type) {
    const icons = {
        'success': 'fa-check-circle',
        'error': 'fa-exclamation-circle',
        'warning': 'fa-exclamation-triangle',
        'info': 'fa-info-circle'
    };
    return icons[type] || 'fa-info-circle';
}

// Mobile modal
function showMobileModal(title, message, actionCallback) {
    currentAction = actionCallback;
    
    document.getElementById('mobile-modal-title').textContent = title;
    document.getElementById('mobile-modal-message').textContent = message;
    document.getElementById('mobile-modal').classList.add('active');
    
    // Prevent body scrolling
    document.body.style.overflow = 'hidden';
}

function closeMobileModal() {
    document.getElementById('mobile-modal').classList.remove('active');
    document.body.style.overflow = '';
    currentAction = null;
}

function confirmMobileAction() {
    if (currentAction) {
        currentAction();
    }
    closeMobileModal();
}

// Loading spinner
function showLoading(show) {
    const spinner = document.getElementById('loading-spinner');
    if (show) {
        spinner.classList.add('active');
        document.body.style.overflow = 'hidden';
    } else {
        spinner.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Pull to refresh
function initPullToRefresh() {
    const mainContent = document.querySelector('.main-content');
    
    mainContent.addEventListener('touchstart', (e) => {
        if (mainContent.scrollTop === 0) {
            pullStartY = e.touches[0].pageY;
        }
    });
    
    mainContent.addEventListener('touchmove', (e) => {
        if (!pullStartY || isRefreshing) return;
        
        const pullDistance = e.touches[0].pageY - pullStartY;
        
        if (pullDistance > 0) {
            e.preventDefault();
            mainContent.style.transform = `translateY(${pullDistance}px)`;
        }
    });
    
    mainContent.addEventListener('touchend', (e) => {
        if (!pullStartY) return;
        
        const pullDistance = e.changedTouches[0].pageY - pullStartY;
        
        if (pullDistance > 100) {
            isRefreshing = true;
            refreshStatus();
        }
        
        mainContent.style.transform = '';
        pullStartY = null;
        
        setTimeout(() => {
            isRefreshing = false;
        }, 1000);
    });
}

// Settings functions
function saveSettings() {
    const serverUrl = document.getElementById('server-url').value;
    const apiToken = document.getElementById('api-token').value;
    const autoRestart = document.getElementById('auto-restart').checked;
    const notifications = document.getElementById('notifications').checked;
    const maxGames = document.getElementById('max-games').value;
    
    localStorage.setItem('ff_server_url', serverUrl);
    localStorage.setItem('ff_api_token', apiToken);
    localStorage.setItem('ff_auto_restart', autoRestart);
    localStorage.setItem('ff_notifications', notifications);
    localStorage.setItem('ff_max_games', maxGames);
    
    showMobileToast('Settings saved', 'success');
}

function loadSettings() {
    const serverUrl = localStorage.getItem('ff_server_url') || 'http://localhost:8000';
    const apiToken = localStorage.getItem('ff_api_token') || 'ff-bot-secret-token-2024';
    const autoRestart = localStorage.getItem('ff_auto_restart') !== 'false';
    const notifications = localStorage.getItem('ff_notifications') !== 'false';
    const maxGames = localStorage.getItem('ff_max_games') || '10';
    
    document.getElementById('server-url').value = serverUrl;
    document.getElementById('api-token').value = apiToken;
    document.getElementById('auto-restart').checked = autoRestart;
    document.getElementById('notifications').checked = notifications;
    document.getElementById('max-games').value = maxGames;
    
    // Load saved credentials
    const savedUid = localStorage.getItem('ff_bot_uid');
    const savedPassword = localStorage.getItem('ff_bot_password');
    const savedTarget = localStorage.getItem('ff_bot_target');
    const savedMode = localStorage.getItem('ff_bot_mode') || 'lone-wolf';
    
    if (savedUid) document.getElementById('mobile-uid').value = savedUid;
    if (savedTarget) {
        document.getElementById('mobile-target-input').value = savedTarget;
        document.getElementById('mobile-target').textContent = savedTarget;
    }
    
    // Select saved mode
    selectMobileMode(savedMode);
}

// App installation
function installApp() {
    if ('serviceWorker' in navigator && 'PushManager' in window) {
        showMobileModal(
            'Install App',
            'Would you like to install this app on your home screen?',
            () => {
                if (window.deferredPrompt) {
                    window.deferredPrompt.prompt();
                    window.deferredPrompt.userChoice.then((choiceResult) => {
                        if (choiceResult.outcome === 'accepted') {
                            showMobileToast('App installed successfully!', 'success');
                        }
                        window.deferredPrompt = null;
                    });
                } else {
                    showMobileToast('App installation not available', 'info');
                }
            }
        );
    } else {
        showMobileToast('PWA not supported on this device', 'info');
    }
}

function clearCache() {
    showMobileModal(
        'Clear Cache',
        'Are you sure you want to clear all cached data?',
        () => {
            localStorage.clear();
            sessionStorage.clear();
            showMobileToast('Cache cleared', 'success');
            setTimeout(() => location.reload(), 1000);
        }
    );
}

function exportLogs() {
    // Implement log export functionality
    showMobileToast('Log export feature coming soon', 'info');
}

function clearLogs() {
    showMobileModal(
        'Clear Logs',
        'Are you sure you want to clear all logs?',
        () => {
            const activityList = document.getElementById('mobile-activity-list');
            const logsContainer = document.getElementById('mobile-logs');
            
            activityList.innerHTML = '';
            logsContainer.innerHTML = '';
            
            showMobileToast('Logs cleared', 'success');
        }
    );
}

// Add activity item
function addMobileActivity(message, type = 'info') {
    const activityList = document.getElementById('mobile-activity-list');
    const now = new Date();
    const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    
    const activityItem = document.createElement('div');
    activityItem.className = 'activity-item';
    activityItem.innerHTML = `
        <span class="activity-time">${timeString}</span>
        <span class="activity-message">${message}</span>
        <span class="activity-type ${type}">${type.toUpperCase()}</span>
    `;
    
    // Add at the beginning
    activityList.insertBefore(activityItem, activityList.firstChild);
    
    // Keep only last 20 items
    const items = activityList.querySelectorAll('.activity-item');
    if (items.length > 20) {
        items[items.length - 1].remove();
    }
    
    // Also add to logs section
    addMobileLog(message, type);
}

function addMobileLog(message, type = 'info') {
    const logsContainer = document.getElementById('mobile-logs');
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    
    const logItem = document.createElement('div');
    logItem.className = 'log-item-mobile';
    logItem.innerHTML = `
        <span class="log-time">${timeString}</span>
        <span class="log-message">${message}</span>
        <span class="log-type ${type}">${type}</span>
    `;
    
    logsContainer.appendChild(logItem);
    logsContainer.scrollTop = logsContainer.scrollHeight;
}

// Network status monitoring
function monitorNetworkStatus() {
    window.addEventListener('online', () => {
        showMobileToast('Back online', 'success');
        updateConnectionStatus('connected');
    });
    
    window.addEventListener('offline', () => {
        showMobileToast('Network connection lost', 'error');
        updateConnectionStatus('disconnected');
    });
    
    // Initial check
    if (!navigator.onLine) {
        showMobileToast('You are offline', 'warning');
        updateConnectionStatus('disconnected');
    }
}

// Initialize mobile app
function initMobileApp() {
    detectDevice();
    loadSettings();
    initPullToRefresh();
    monitorNetworkStatus();
    
    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
    
    // Initialize service worker for PWA
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/service-worker.js')
            .then(() => console.log('Service Worker registered'))
            .catch(err => console.log('Service Worker registration failed:', err));
    }
    
    // Handle app installation
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        window.deferredPrompt = e;
    });
    
    // Load saved data
    const savedGames = localStorage.getItem('ff_games_played') || '0';
    const savedUptime = localStorage.getItem('ff_uptime') || '0';
    const savedSuccess = localStorage.getItem('ff_success_rate') || '0';
    
    document.getElementById('mobile-games-played').textContent = savedGames;
    document.getElementById('mobile-uptime').textContent = `${savedUptime}m`;
    document.getElementById('mobile-success').textContent = `${savedSuccess}%`;
    
    // Add some initial activities
    addMobileActivity('Mobile app initialized', 'info');
    addMobileActivity('Ready to control bot', 'success');
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initMobileApp);