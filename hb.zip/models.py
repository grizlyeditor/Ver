from pydantic import BaseModel, Field, validator
from typing import Optional, Dict, Any, List
from enum import Enum
from datetime import datetime

class GameMode(str, Enum):
    LONE_WOLF = "lone-wolf"
    SQUAD = "squad"
    DUO = "duo"
    RANKED = "ranked"

class BotStatus(BaseModel):
    status: str = Field("offline", description="Current bot status")
    games_played: int = Field(0, description="Total games played")
    games_won: int = Field(0, description="Games won")
    games_lost: int = Field(0, description="Games lost")
    avg_play_time: float = Field(0.0, description="Average play time in minutes")
    success_rate: float = Field(0.0, description="Success rate percentage")
    uptime_seconds: int = Field(0, description="Bot uptime in seconds")
    last_activity: Optional[datetime] = None
    current_target: Optional[str] = None
    current_mode: GameMode = GameMode.LONE_WOLF
    connection_status: str = Field("disconnected", description="Game connection status")
    errors: List[str] = Field([], description="Recent errors")
    warnings: List[str] = Field([], description="Recent warnings")
    
    @validator('success_rate')
    def validate_success_rate(cls, v):
        return round(max(0.0, min(100.0, v)), 2)

class BotConfig(BaseModel):
    uid: str = Field(..., description="Free Fire account UID")
    password: str = Field(..., description="Account password/access token")
    target_player: Optional[str] = Field(None, description="Target player ID")
    game_mode: GameMode = Field(GameMode.LONE_WOLF, description="Game mode to play")
    max_games: Optional[int] = Field(10, description="Maximum games to play")
    auto_restart: bool = Field(True, description="Auto-restart on failure")
    check_interval: int = Field(5, description="Status check interval in seconds")
    region: str = Field("global", description="Game region")
    
    @validator('max_games')
    def validate_max_games(cls, v):
        if v is not None and v < 1:
            raise ValueError("max_games must be at least 1")
        return v
    
    @validator('check_interval')
    def validate_check_interval(cls, v):
        if v < 1:
            raise ValueError("check_interval must be at least 1 second")
        return v

class Command(BaseModel):
    command: str = Field(..., description="Command type")
    data: Dict[str, Any] = Field({}, description="Command data")
    timestamp: datetime = Field(default_factory=datetime.now)
    
    @validator('command')
    def validate_command(cls, v):
        valid_commands = {'start', 'stop', 'restart', 'pause', 'resume', 'set_target', 'change_mode', 'status'}
        if v not in valid_commands:
            raise ValueError(f"Invalid command. Must be one of: {valid_commands}")
        return v

class LoginRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=6, max_length=100)