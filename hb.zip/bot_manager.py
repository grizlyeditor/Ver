import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Dict, Optional
from datetime import datetime
import subprocess

from app.models import BotConfig, BotStatus

logger = logging.getLogger(__name__)

class BotManager:
    def __init__(self):
        self.active_bots: Dict[str, Dict] = {}
        self.bot_processes: Dict[str, asyncio.subprocess.Process] = {}
        
    async def start_bot(self, bot_id: str, config: BotConfig) -> bool:
        try:
            status = BotStatus(
                status="starting",
                current_target=config.target_player,
                current_mode=config.game_mode
            )
            
            self.active_bots[bot_id] = {
                "config": config,
                "status": status,
                "started_at": datetime.now(),
                "stats": {"games_played": 0}
            }
            
            # Start bot process
            process = await self._create_bot_process(bot_id, config)
            
            if process:
                self.bot_processes[bot_id] = process
                asyncio.create_task(self._monitor_bot(bot_id, process))
                logger.info(f"Bot {bot_id} started")
                return True
            else:
                del self.active_bots[bot_id]
                return False
                
        except Exception as e:
            logger.error(f"Error starting bot: {str(e)}")
            return False
            
    async def _create_bot_process(self, bot_id: str, config: BotConfig) -> Optional[asyncio.subprocess.Process]:
        try:
            # Create bot runner command
            cmd = [
                sys.executable,
                "bot_runner.py",
                "--bot-id", bot_id,
                "--uid", config.uid,
                "--password", config.password,
                "--mode", config.game_mode,
                "--region", config.region
            ]
            
            if config.target_player:
                cmd.extend(["--target", config.target_player])
                
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=".."  # Run from parent directory
            )
            
            asyncio.create_task(self._read_bot_output(bot_id, process.stdout))
            
            return process
            
        except Exception as e:
            logger.error(f"Error creating process: {str(e)}")
            return None
            
    async def _read_bot_output(self, bot_id: str, stream: asyncio.StreamReader):
        try:
            while True:
                line = await stream.readline()
                if not line:
                    break
                    
                line = line.decode().strip()
                if line:
                    await self._handle_bot_output(bot_id, line)
                    
        except Exception as e:
            logger.error(f"Error reading output: {str(e)}")
            
    async def _handle_bot_output(self, bot_id: str, output: str):
        try:
            if bot_id not in self.active_bots:
                return
                
            data = json.loads(output)
            message_type = data.get("type")
            
            if message_type == "status":
                await self._update_bot_status(bot_id, data.get("data", {}))
            elif message_type == "log":
                logger.info(f"Bot {bot_id}: {data.get('message')}")
                
        except json.JSONDecodeError:
            logger.info(f"Bot {bot_id}: {output}")
        except Exception as e:
            logger.error(f"Error handling output: {str(e)}")
            
    async def _update_bot_status(self, bot_id: str, status_data: Dict):
        if bot_id in self.active_bots:
            bot_data = self.active_bots[bot_id]
            current_status = bot_data["status"]
            
            for key, value in status_data.items():
                if hasattr(current_status, key):
                    setattr(current_status, key, value)
                    
            current_status.last_activity = datetime.now()
            
            # Update uptime
            if current_status.status == "running":
                uptime = (datetime.now() - bot_data["started_at"]).total_seconds()
                current_status.uptime_seconds = int(uptime)
                
    async def _monitor_bot(self, bot_id: str, process: asyncio.subprocess.Process):
        try:
            return_code = await process.wait()
            
            if bot_id in self.active_bots:
                bot_data = self.active_bots[bot_id]
                bot_data["status"].status = "stopped"
                
            if bot_id in self.bot_processes:
                del self.bot_processes[bot_id]
                
            logger.info(f"Bot {bot_id} stopped with code {return_code}")
            
        except Exception as e:
            logger.error(f"Error monitoring bot: {str(e)}")
            
    async def stop_bot(self, bot_id: str) -> bool:
        try:
            if bot_id not in self.bot_processes:
                return False
                
            process = self.bot_processes[bot_id]
            
            # Send stop command
            if process.stdin:
                stop_cmd = json.dumps({"command": "stop"})
                process.stdin.write(stop_cmd.encode() + b'\n')
                await process.stdin.drain()
                
            # Wait for stop
            try:
                await asyncio.wait_for(process.wait(), timeout=10)
            except asyncio.TimeoutError:
                process.terminate()
                
            if bot_id in self.active_bots:
                self.active_bots[bot_id]["status"].status = "stopped"
                
            if bot_id in self.bot_processes:
                del self.bot_processes[bot_id]
                
            return True
            
        except Exception as e:
            logger.error(f"Error stopping bot: {str(e)}")
            return False
            
    async def send_to_bot(self, bot_id: str, message: Dict) -> bool:
        try:
            if bot_id not in self.bot_processes:
                return False
                
            process = self.bot_processes[bot_id]
            
            if process.stdin:
                message_str = json.dumps(message)
                process.stdin.write(message_str.encode() + b'\n')
                await process.stdin.drain()
                return True
                
        except Exception as e:
            logger.error(f"Error sending to bot: {str(e)}")
            
        return False
        
    async def stop_all_bots(self):
        for bot_id in list(self.bot_processes.keys()):
            await self.stop_bot(bot_id)